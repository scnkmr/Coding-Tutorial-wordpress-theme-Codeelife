<?php
/**
 Template Name: CPP Template
 Description: This is template for C programming
 * @package CodeeLife
 */

get_header();
?>
<br><br><br>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-3">
			<div class="dropdown sidebar sidebar-md">
				<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					Topic			<span class="caret"></span>
				</button>
						<?php
					 $nav_menu_locations = get_nav_menu_locations();
					 $menu_id = 0;
					 if (isset($nav_menu_locations['cpp-menu']) && absint($nav_menu_locations['cpp-menu']) > 0) {
						 $menu_id = absint($nav_menu_locations['cpp-menu']);
					 }
					 if ($menu_id > 0) {
						 $menu_items = wp_get_nav_menu_items($menu_id);
						 if (!empty($menu_items)) {
							 echo '<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
							 <li class="dropdown-header"> C++ Tutorial</li>';
							 foreach ($menu_items as $m_key => $m) {
								 echo '<li class="'.check_active_menu($m).'">';
								 echo '<a href="' . esc_url($m->url) . '">';
								 echo '<span class="title screen-reader-text">' . esc_attr($m->title) . '</span>';
								 echo '</a>';
								 echo '</li>';
							 }
							 echo '</ul>';
						 }
					 }
						?>
			</div>
		</div>
		<div class="col-sm-7">
		<br>
					<?php
					 $nav_menu_locations1 = get_nav_menu_locations();
					 $menu_id1 = 0;
					 if (isset($nav_menu_locations1['c-menu']) && absint($nav_menu_locations1['c-menu']) > 0) {
						 $menu_id1 = absint($nav_menu_locations1['c-menu']);
					 }
					 if ($menu_id1 > 0) {
						 $menu_items1 = wp_get_nav_menu_items($menu_id1);
						 if (!empty($menu_items1)) {
							 $np_title=array();
							 $np_url=array();
							 $np_next=0;
							 $np_prev=0;
							 //$np_length_of_menu=99999;
							 foreach ($menu_items1 as $m_key1 => $m1) {
								 $np_title[$m_key1]=esc_attr($m1->title);
								 $np_url[$m_key1]=esc_url($m1->url);
								 
								 $np_current_link=( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
								 if($np_current_link==$m1->url){
									 $np_next=$m_key1+1;
									 $np_prev=$m_key1-1;
								 }
							 }
							 if($np_prev>=0){
								echo '<a href="'.$np_url[$np_prev].'"><button class="btn btn-lg btn-primary" style="background:#18454A"><i class="glyphicon glyphicon-circle-arrow-left"></i>   '.$np_title[$np_prev].'</button></a>';
							 }
							 if($np_next<count($menu_items1)){
								echo '<a href="'.$np_url[$np_next].'"><button class="btn btn-lg btn-primary" style="background:#18454A;float:right;display:inline-block;">'.$np_title[$np_next].'    <i class="glyphicon glyphicon-circle-arrow-right"></i></button></a>';
							 }
							 
						 }
					 }
						?>
						<hr>
			<?php
			while ( have_posts() ) :
				the_post();

				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>
			<hr>
			<?php
					 $nav_menu_locations1 = get_nav_menu_locations();
					 $menu_id1 = 0;
					 if (isset($nav_menu_locations1['c-menu']) && absint($nav_menu_locations1['c-menu']) > 0) {
						 $menu_id1 = absint($nav_menu_locations1['c-menu']);
					 }
					 if ($menu_id1 > 0) {
						 $menu_items1 = wp_get_nav_menu_items($menu_id1);
						 if (!empty($menu_items1)) {
							 $np_title=array();
							 $np_url=array();
							 $np_next=0;
							 $np_prev=0;
							 //$np_length_of_menu=99999;
							 foreach ($menu_items1 as $m_key1 => $m1) {
								 $np_title[$m_key1]=esc_attr($m1->title);
								 $np_url[$m_key1]=esc_url($m1->url);
								 
								 $np_current_link=( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
								 if($np_current_link==$m1->url){
									 $np_next=$m_key1+1;
									 $np_prev=$m_key1-1;
								 }
							 }
							 if($np_prev>=0){
								echo '<a href="'.$np_url[$np_prev].'"><button class="btn btn-lg btn-primary" style="background:#18454A"><i class="glyphicon glyphicon-circle-arrow-left"></i>   '.$np_title[$np_prev].'</button></a>';
							 }
							 if($np_next<count($menu_items1)){
								echo '<a href="'.$np_url[$np_next].'"><button class="btn btn-lg btn-primary" style="background:#18454A;float:right;display:inline-block;">'.$np_title[$np_next].'    <i class="glyphicon glyphicon-circle-arrow-right"></i></button></a>';
							 }
							 
						 }
					 }
						?>
						<br>
            
		</div>
        
<?php
    get_sidebar();
	get_footer();
	?>
