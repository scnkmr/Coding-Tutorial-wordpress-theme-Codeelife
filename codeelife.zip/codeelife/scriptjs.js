function printArticle(tag){
	
	var head=document.getElementsByTagName('head')[0].innerHTML;
	var content=document.getElementsByTagName(tag)[0].innerHTML;
	var myWindow = window.open('', '', '');
    myWindow.document.write('<!doctype html><html lang="en-US"><head>'+head+'<style>@media print{.btn{display:none;}}</style></head><body><center><button class=btn btn-primary btn-lg" onclick="print()">Print Page (Ctrl + P)</button></center>'+content+'<p>&copy 2020 by codeelife.com | All Rights Reserved.</p></body></html>');
}