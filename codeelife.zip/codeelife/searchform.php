<form method="get" class="navbar-form navbar-left">
    <input type="text" name="s" id="search" class="form-control" placeholder="Topic? " value="<?php the_search_query(); ?>" />
    <input type="submit" alt="Search" class="form-control" value="Search" />
</form>