<?php
/**
 * CodeeLife functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package CodeeLife
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

if ( ! function_exists( 'codeelife_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function codeelife_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on CodeeLife, use a find and replace
		 * to change 'codeelife' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'codeelife', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'menu-1' => esc_html__( 'Primary', 'codeelife' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'codeelife_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'codeelife_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function codeelife_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'codeelife_content_width', 640 );
}
add_action( 'after_setup_theme', 'codeelife_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function codeelife_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'codeelife' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'codeelife' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'codeelife_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function codeelife_scripts() {
	wp_enqueue_style( 'codeelife-style', get_stylesheet_uri(), array(), _S_VERSION );

	wp_enqueue_script( 'codeelife-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	wp_enqueue_script( 'codeelife-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'codeelife_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

function register_my_menus() {
  register_nav_menus(
    array(
      'java-menu' => __( 'Java Menu' ),
      'c-menu' => __( 'C Menu' ),
	  'python-menu' => __( 'Python Menu' ),
	  'important-link' => __('Important Links'),
	  'course-menu' => __('Course Link'),
	  'html-menu' => __('HTML Menu'),
	  'cpp-menu' => __('C++ Menu'),
	  'php-menu' => __('PHP Menu'),
	  'dsa-menu' => __('DSA Menu'),
	  'footer-tutorial' => __('Footer Tutorial'),
	  'footer-about' => __('Footer About'),
	  'footer-social-link' => __('Footer Social Link')
    )
  );
}
add_action( 'init', 'register_my_menus' );

//This function is for .active in current menu
	function check_active_menu( $menu_item ) {
    $actual_link = ( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    if ( $actual_link == $menu_item->url ) {
        return 'active';
    }
    return '';
}
//left side menu for tutorial
function left_menu_for($menu_name,$category_ref){
	$nav_menu_locations = get_nav_menu_locations();
					 $menu_id = 0;
					 if (isset($nav_menu_locations[$menu_name]) && absint($nav_menu_locations[$menu_name]) > 0) {
						 $menu_id = absint($nav_menu_locations[$menu_name]);
					 }
					 if ($menu_id > 0) {
						 $menu_items = wp_get_nav_menu_items($menu_id);
						 if (!empty($menu_items)) {
							 echo '<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">';
							 //<li class="dropdown-header">'.wp_get_nav_menu_name($menu_name).'</li>';
							 $sr_no=0;
							 
							 //$category_ref=array("Basic"=>2,"OOPS"=>4,"Advance"=>5);
							 
							 foreach ($menu_items as $m_key => $m) {
								 if($m_key+1==current($category_ref)){
									 echo '<li class="dropdown-header" style="color: #333;font-size:18px;">'.implode(array_keys($category_ref,current($category_ref))).'</li>';
									 next($category_ref);
								 }
								 
								 $sr_no++;
								 echo '<li class="'.check_active_menu($m).'">';
								 echo '<a href="' . esc_url($m->url) . '">'.$sr_no.'. ';
								 echo '<span class="title screen-reader-text">' . esc_attr($m->title) . '</span>';
								 echo '</a>';
								 echo '</li>';
								 
							 }
							 echo '</ul>';
						 }
					 }
}

//Next and Previous Menu 
function next_prev_button_for($menu_name){
	$nav_menu_locations1 = get_nav_menu_locations();
					 $menu_id1 = 0;
					 if (isset($nav_menu_locations1[$menu_name]) && absint($nav_menu_locations1[$menu_name]) > 0) {
						 $menu_id1 = absint($nav_menu_locations1[$menu_name]);
					 }
					 if ($menu_id1 > 0) {
						 $menu_items1 = wp_get_nav_menu_items($menu_id1);
						 if (!empty($menu_items1)) {
							 $np_title=array();
							 $np_url=array();
							 $np_next=0;
							 $np_prev=0;
							 //$np_length_of_menu=99999;
							 foreach ($menu_items1 as $m_key1 => $m1) {
								 $np_title[$m_key1]=esc_attr($m1->title);
								 $np_url[$m_key1]=esc_url($m1->url);
								 
								 $np_current_link=( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
								 if($np_current_link==$m1->url){
									 $np_next=$m_key1+1;
									 $np_prev=$m_key1-1;
								 }
							 }
							 if($np_prev>=0){
								echo '<a href="'.$np_url[$np_prev].'"><button class="btn btn-lg btn-primary" style="background:#18454A"><i class="glyphicon glyphicon-circle-arrow-left"></i>   '.$np_title[$np_prev].'</button></a>';
							 }
							 if($np_next<count($menu_items1)){
								echo '<a href="'.$np_url[$np_next].'"><button class="btn btn-lg btn-primary" style="background:#18454A;float:right;display:inline-block;">'.$np_title[$np_next].'    <i class="glyphicon glyphicon-circle-arrow-right"></i></button></a>';
							 }
							 
						 }
					 }
}