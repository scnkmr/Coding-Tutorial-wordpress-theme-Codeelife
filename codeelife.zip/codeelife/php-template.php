<?php
/**
 Template Name: PHP Template
 Description: This is template for C programming
 * @package CodeeLife
 */

get_header();
?>
<br><br><br>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-3">
			<div class="dropdown sidebar sidebar-md">
				<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					Topic			<span class="caret"></span>
				</button>
						<?php
					 $nav_menu_locations = get_nav_menu_locations();
					 $menu_id = 0;
					 if (isset($nav_menu_locations['php-menu']) && absint($nav_menu_locations['php-menu']) > 0) {
						 $menu_id = absint($nav_menu_locations['php-menu']);
					 }
					 if ($menu_id > 0) {
						 $menu_items = wp_get_nav_menu_items($menu_id);
						 if (!empty($menu_items)) {
							 echo '<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
							 <li class="dropdown-header"> PHP Tutorial</li>';
							 foreach ($menu_items as $m_key => $m) {
								 echo '<li class="'.check_active_menu($m).'">';
								 echo '<a href="' . esc_url($m->url) . '">';
								 echo '<span class="title screen-reader-text">' . esc_attr($m->title) . '</span>';
								 echo '</a>';
								 echo '</li>';
							 }
							 echo '</ul>';
						 }
					 }
						?>
			</div>
		</div>
		<div class="col-sm-7">
			<?php
			while ( have_posts() ) :
				the_post();

				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>
            
		</div>
        
<?php
    get_sidebar();
	get_footer();
	?>
