<?php
/**
 Template Name: Java Template
 Description: This is template for java
 * @package CodeeLife
 */

get_header();
?>
<br><br><br>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-3">
			<div class="dropdown sidebar sidebar-md">
				<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					Topic			<span class="caret"></span>
				</button>
						<?php left_menu_for('java-menu',["Basic Java"=>1,"OOPS Concept"=>21,"Advance Topics"=>28]); ?>
			</div>
		</div>
		<div class="col-sm-7">
					<br>
					<?php next_prev_button_for('java-menu'); ?>
						<hr>
			<?php
			while ( have_posts() ) :
				the_post();

				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>
            <hr>
			<?php next_prev_button_for('java-menu'); ?>
		</div>
        
<?php
    get_sidebar();
	get_footer();
	?>
