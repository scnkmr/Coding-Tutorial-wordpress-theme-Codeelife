<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CodeeLife
 */

?>
	
	</div>
	</div><br>
        <footer>
            <div class="container-fluid footer-tagline"><h4>Coding is Easy</h4></div><br>
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <?php the_custom_logo(); ?>
                        <h4>Coding is Easy</h4>
                        <p>We bring Detailed & Easiest Online Coding Tutorial. Where Everyone Can learn Coding in Easiest Way.</p>
                    </div>
                    <div class="col-sm-3">
                        <h4>Tutorials</h4>
                        <?php
							wp_nav_menu(
								array(
									'theme_location' => 'footer-tutorial',
									'menu_class'        => 'c-menu-ul',
								)
							);
							?>
                    </div>
                    <div class="col-sm-3">
					<h4>About</h4>
                        <?php
							wp_nav_menu(
								array(
									'theme_location' => 'footer-about',
									'menu_class'        => 'c-menu-ul',
								)
							);
							?>
					</div>
                    <div class="col-sm-3">
                        <h4>Social link</h4>
							<?php
										wp_nav_menu(
											array(
												'theme_location' => 'footer-social-link',
												'menu_class'        => 'c-menu-ul',
											)
										);
										?>
                    </div>
                </div>
				<br>
                <div class="row" style="text-align: center;">
                     &copy; 2020 Codeelife.com  
					<?php
					/* translators: 1: Theme name, 2: Theme author. */
					//printf( esc_html__( 'Theme: %1$s by %2$s.', 'codeelife' ), 'codeelife', '<a href="http://www.sachinthakur.in">Sachin Arayans</a>' );
					?>
                </div>
				<br>
            </div>
        </footer>
	<?php wp_footer(); ?>
    </body>
</html>
