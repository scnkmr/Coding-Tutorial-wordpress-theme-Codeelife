<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package CodeeLife
 */

get_header();
?>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-3">
			<div class="dropdown sidebar sidebar-md">
				<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
					Dropdown
					<span class="caret"></span>
				</button>
				<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
					<li class="dropdown-header">Job Type</li>
					<li class="active"><a href="#">Action</a></li>
					<li><a href="#">Another action</a></li>
					<li><a href="#">Something else here</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="#">Separated link</a></li>
					<li class="dropdown-header">Specialism</li>
					<li><a href="#">Action</a></li>
					<li><a href="#">Another action</a></li>
					<li><a href="#">Something else here</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="#">Separated link</a></li>
					<li class="dropdown-header">Sample</li>
					<li><a href="#">Action</a></li>
					<li><a href="#">Another action</a></li>
					<li><a href="#">Something else here</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="#">Separated link</a></li>
				</ul>
			</div>
		</div>
		<div class="col-sm-7">
            <h1>Page Title</h1>
			<p>Move the needle inclusive improve the world white paper uplift co-create NGO thought provoking strengthening infrastructure. Leverage external partners move the needle energize save the world changemaker shared unit of analysis our work communities. Capacity building save the world shine commitment; deep dive low-hanging fruit innovate, indicators thought leader co-create because disrupt game-changer.</p>

			<p>Energize; energize global, social entrepreneurship social entrepreneur. Outcomes citizen-centered empathetic boots on the ground design thinking thought partnership but leverage co-creation save the world. Mobilize, communities; when movements, scale and impact scale and impact; agile then thought partnership state of play support. Capacity building empower communities, engaging social intrapreneurship, natural resources triple bottom line thought leadership or design thinking.</p>

			<p>Sustainable venture philanthropy; impact design thinking academic, families program area social impact thought partnership justice incubator gender rights milestones. Radical a her body her rights; storytelling our work equal opportunity resilient green space inspiring thought partnership parse. Indicators compelling outcomes entrepreneur, milestones, global low-hanging fruit targeted external partners thought leader overcome injustice challenges and opportunities. Justice radical move the needle scale and impact communities greenwashing. A, silo revolutionary strategize empower communities inspiring shine, improve the world strategize. Leverage; social enterprise, LGBTQ+, incubator shine inspiring parse game-changer systems thinking inclusion.</p>
			<p>Move the needle inclusive improve the world white paper uplift co-create NGO thought provoking strengthening infrastructure. Leverage external partners move the needle energize save the world changemaker shared unit of analysis our work communities. Capacity building save the world shine commitment; deep dive low-hanging fruit innovate, indicators thought leader co-create because disrupt game-changer.</p>

			<p>Energize; energize global, social entrepreneurship social entrepreneur. Outcomes citizen-centered empathetic boots on the ground design thinking thought partnership but leverage co-creation save the world. Mobilize, communities; when movements, scale and impact scale and impact; agile then thought partnership state of play support. Capacity building empower communities, engaging social intrapreneurship, natural resources triple bottom line thought leadership or design thinking.</p>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<p>Sustainable venture philanthropy; impact design thinking academic, families program area social impact thought partnership justice incubator gender rights milestones. Radical a her body her rights; storytelling our work equal opportunity resilient green space inspiring thought partnership parse. Indicators compelling outcomes entrepreneur, milestones, global low-hanging fruit targeted external partners thought leader overcome injustice challenges and opportunities. Justice radical move the needle scale and impact communities greenwashing. A, silo revolutionary strategize empower communities inspiring shine, improve the world strategize. Leverage; social enterprise, LGBTQ+, incubator shine inspiring parse game-changer systems thinking inclusion.</p>
		</div>
        <div class="col-sm-2 r-side">
          <center> <img src="/assets/banner.png" style="height: 600px;width: 160px;"></center>
            <hr>
            <h4>Important Link</h4>
            <ul class="c-menu-ul">
              <li><a href="#">Coffee</a></li>
              <li>Tea</li>
              <li>Milk</li>
                <li>Coffee</li>
              <li>Tea</li>
              <li>Milk</li><li>Coffee</li>
              <li>Tea</li>
              <li>Milk</li>
                <li>Coffee</li>
              <li>Tea</li>
              <li>Milk</li>
                <li>Coffee</li>
              <li>Tea</li>
              <li>Milk</li>
            </ul>
            <hr>
            <center> <img src="/assets/banner.png" style="height: 600px;width: 160px;" data-spy="affix" data-offset-top="1050"></center>
        </div>
	</div>
<?php
	get_footer();
	?>
