<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CodeeLife
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<div class="col-sm-2 r-side">
         <br> <center>SHARE THIS PAGE <br> 
		 <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink();?>&t=<?php the_title_attribute(); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" title="Share on Facebook"> <i class="fab fa-facebook-f"></i></a>
		 <a href="https://twitter.com/share?url=<?php the_permalink();?>&text=<?php the_title_attribute(); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" title="Share on Twitter"><i class="fab fa-twitter"></i></a> 
		 <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink();?>&t=<?php the_title_attribute(); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" title="Share on Linkedin"><i class="fab fa-linkedin-in"></i></a>
		 <br><br>
		 <a href="javascript:void(0)"></a>
		 <button class="btn btn-primary" title="Print This Page" onclick="printArticle('article')"><i class="fa fa-print"></i> Print Page</button>
		 <br>
		 </center> 
		 <br> <center> <img src="<?php echo get_template_directory_uri().'/assets/banner.png' ?>" style="height: 600px;width: 160px;"></center>
            <hr>
            <h4>Important Link</h4>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'important-link',
					'menu_class'        => 'c-menu-ul',
				)
			);
			?>
            <hr>
<script src="https://www.codeelife.com/wp-content/themes/codeelife/scriptjs.js"></script>
        </div>
