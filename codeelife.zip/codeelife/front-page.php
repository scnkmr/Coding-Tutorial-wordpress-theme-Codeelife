<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package CodeeLife
 */

get_header();
?>
<style>
	.clide-area{
				text-align: center;
			}
</style>
<div class="container-fluid clide-container">
<div class="row">
<div class="col-sm-12">
<div class="clide-area">
<br><br>
<h1><i class="fa fa-code"></i> CODING IS EASY</h1><br>
<p style="font-size: 20px">We bring Detailed & Easiest Online Coding Tutorial.<br> Where Everyone Can learn Coding in Easiest Way.</p>
<h1>Start Learning ⇩</h1>
<!--
Used to give notification on websitet 
<marquee><h1 style="opacity: 0.1;">_welcome to CodeeLife.com</h1></marquee>  -->
    <img src="<?php echo get_template_directory_uri().'/assets/india.svg' ?>" style="opacity: 0.3; width: 100%; max-width: 500px; height:auto;">



<br>
</div>
</div>
</div>
</div>
<br><br>
<style>
			
			.course-icon-main-div{
				    box-sizing: border-box;
					box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
			}
			.course-icon-main-div a{
				color: rgb(73,80,87);
				text-decoration: none;
				text-align: center;
				transition: 0.3s;
			}
			.course-icon-main-div:hover a:hover{
				color: #fff;
			}
			.course-icon-main-div h1{
				background: rgba(0,0,0,0.1);
				padding: 12px;
			}
			.course-icon-main-div i{
				font-size: 100px;
				padding: 20px;
			}
			#java-course-icon{
				background: #e3fafc;
				transition: 0.3s;
			}
			#java-course-icon:hover{
				background: #22b8cf;
			}
			#c-course-icon{
				background: #fff5f5;
				transition: 0.3s;
			}
			#c-course-icon:hover{
				background: #ff6b6b;
			}
			#python-course-icon{
				background: #e6fcf5;
				transition: 0.3s;
			}
			#python-course-icon:hover{
				background: #20c997;
			}
			#html-course-icon{
				background: #fff9db;
				transition: 0.3s;
			}
			#html-course-icon:hover{
				background: #fcc419;
			}
			#css-course-icon{
				background: #f3f0ff;
				transition: 0.3s;
				display:none;
			}
			#css-course-icon:hover{
				background: #845ef7;
			}
			#js-course-icon{
				background: #e7f5ff;
				transition: 0.3s;
				display:none;
			}
			#js-course-icon:hover{
				background: #339af0;
			}
			#php-course-icon{
				background: #f4fce3;
				transition: 0.3s;
				display:none;
			}
			#php-course-icon:hover{
				background: #94d82d;
			}
			#sql-course-icon{
				background: #fff0f6;
				transition: 0.3s;
				display:none;
			}
			#sql-course-icon:hover{
				background: #f06595;
			}
			#asp-course-icon{
				background: #fff4e6;
				transition: 0.3s;
				display:none;
			}
			#asp-course-icon:hover{
				background: #ff922b;
			}
			#cpp-course-icon{
				background: #ebfbee;
				transition: 0.3s;
			}
			#cpp-course-icon:hover{
				background: #51cf66;
			}
			#dsa-course-icon{
				background: #f8f0fc;
				transition: 0.3s;
			}
			#dsa-course-icon:hover{
				background: #cc5de8;
			}
		</style>
<div class="container-fluid">
	<div class="row">
	<div class="container">
		<div class="row">
		
			<div class="col-sm-4">
				<div class="course-icon-main-div" id="java-course-icon">
				<a href="http://www.codeelife.com/java/">
				<div>
					<div><i class="fab fa-java"></i>
					</div>
					<h1>JAVA</h1>
				</div>
				</a>
				</div><br>
			</div>
			<div class="col-sm-4">
			<div class="course-icon-main-div" id="c-course-icon">
				<a href="http://www.codeelife.com/c-programming/">
				<div>
					<div><i class="fab fa-cuttlefish"></i>
					</div>
					<h1>C PROGRAMMING</h1>
				</div>
				</a>
				</div><br></div>
			<div class="col-sm-4"><div class="course-icon-main-div" id="python-course-icon">
				<a href="http://www.codeelife.com/python/">
				<div>
					<div><i class="fab fa-python"></i>
					</div>
					<h1>PYTHON</h1>
				</div>
				</a>
				</div><br>
				</div>
			
		</div>
		<div class="row">
		
			<div class="col-sm-4">
				<div class="course-icon-main-div" id="html-course-icon">
				<a href="http://www.codeelife.com/html/">
				<div>
					<div><i class="fab fa-html5"></i>
					</div>
					<h1>HTML</h1>
				</div>
				</a>
				</div><br>
			</div>
			<div class="col-sm-4">
			<div class="course-icon-main-div" id="cpp-course-icon">
				<a href="http://www.codeelife.com/cpp/">
				<div>
					<div><i class="fa fa-laptop-code"></i>
					</div>
					<h1>C++</h1>
				</div>
				</a>
				</div><br></div>
				<div class="col-sm-4">
			<div class="course-icon-main-div" id="dsa-course-icon">
				<a href="http://www.codeelife.com/dsa/">
				<div>
					<div><i class="fa fa-project-diagram"></i>
					</div>
					<h1>Data Structure</h1>
				</div>
				</a>
				</div><br></div>
				
			<div class="col-sm-4">
			<div class="course-icon-main-div" id="css-course-icon">
				<a href="javascript:void(0)">
				<div>
					<div><i class="fab fa-css3-alt"></i>
					</div>
					<h1>CSS</h1>
				</div>
				</a>
				</div><br></div>
			<div class="col-sm-4"><div class="course-icon-main-div" id="js-course-icon">
				<a href="javascript:void(0)">
				<div>
					<div><i class="fab fa-js"></i>
					</div>
					<h1>JavaScript</h1>
				</div>
				</a>
				</div><br>
				</div>
			
		</div>
		<div class="row">
		
			<div class="col-sm-4">
				<div class="course-icon-main-div" id="php-course-icon">
				<a href="javascript:void(0)">
				<div>
					<div><i class="fab fa-php"></i>
					</div>
					<h1>PHP</h1>
				</div>
				</a>
				</div><br>
			</div>
			<div class="col-sm-4">
			<div class="course-icon-main-div" id="sql-course-icon">
				<a href="javascript:void(0)">
				<div>
					<div><i class="fa fa-database"></i>
					</div>
					<h1>SQL</h1>
				</div>
				</a>
				</div><br></div>
			<div class="col-sm-4"><div class="course-icon-main-div" id="asp-course-icon">
				<a href="javascript:void(0)">
				<div>
					<div><i class="fa fa-server"></i>
					</div>
					<h1>ASP</h1>
				</div>
				</a>
				</div><br>
				</div>
			
		</div>
		
</div>	

<?php
	get_footer();
	?>
